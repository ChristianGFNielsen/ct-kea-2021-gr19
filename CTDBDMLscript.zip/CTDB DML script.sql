-- Database for handling and storing information regarding CodersTrusts users, who fill out the "career-quiz".
-- Developed by Jacob Berg, Jørn Møller, Alexander Broersen, Eliza Hansen and Christian F.-Nielsen. 
-- Group 19, 2. semester BE-IT KEA 2021

-- ********************************************
-- INSERT INTO THE CTDB DATABASE
-- *******************************************

-- Using the database
use ctdb;

-- Inserting into the categories table
-- the inserted values in categories table are "Creative", "Development" and "Digital Marketing".
-- These are the categories that CodersTrust wants to divide their users in. Should CodersTrust want
-- to add more categories, it is possible to do so in the Insert statement below.
INSERT INTO categories (
	categoryName)
VALUES 
	("Creative"),
    ("Development"),
    ("Digital Marketing");
    

-- Inserting into the questions table
-- the inserted values in the questions table are the questions given to us by CodersTrust together with the ID
-- if each category that the given question is related to.
-- Should CodersTrust want to add more questions, it is possible to do so in the Insert statement below,
-- inserting the categoryID first followed by the question description.    
INSERT INTO questions (
	categoryID, questionDescription)
VALUES
	(1, "Do you appreciate design in relation to products?"),
    (1, "Do you have a favourite artist when it comes to visual art?"),
    (1, "Do you enjoy making visual presentations for school or business?"),
    (1, "Have you tried editing video on your mobile device or PC?"),
    
    (2, "Do you like to take online intelligence tests?"),
    (2, "Do you find numbers and logic is preferred over philosophical questions?"),
    (2, "Are you interested in coding and learning to either understand or code yourself?"),
    (2, "Have you tried building a website with a CMS like wordpress or Wix?"),
    
    (3, "Are you very active on Social Media?"),
    (3, "Do you care about who likes and comments on your posts?"),
    (3, "Do you find that Social Media influences your buying decisions?"),
    (3, "Do you believe that Social Media is more effective than traditional marketing?");
    
-- Inserting into the users table
-- The values inserted in the users table are the values defining each user who has taken the entire quiz.
-- A user is not to be stored in the database unless he/she has answered all questions in the quiz.
-- If a user goes through the entire quiz, this user will be stored in the database and their relevant information with it.
-- As shown in the insert statements below, a user can be logged in and by then give the information; userName, password
-- and userEmail. If the user is not logged in, null values will be stored for all attributes except userID.
INSERT INTO users (
	userName, userPassword, userEmail)
VALUES
	("John44", "1234", "john44@gmail.com"),
    ("AnikTheFreelancer", "1234", "AnikFLance@gmail.com"),
    ("Deniz123", "1234", "john123@hotmail.com"),
    ("KarenTheKaren", "1234", "GetOffMyProperty@Racist.com"),
    ("Skadoodle", "1234", "CSGOSkDoodle@valve.com"),
    ("JesusChrist", "1234", "LordAndSavior@Heaven.com"),
    ("MuhammadAli", "1234", "MuAli@KO.com"),
    (NULL, NULL, NULL),
    (NULL, NULL, NULL);
    
-- Inserting into the userquestions table.
-- Here all the values of the other tables in the database come together.
-- the userID of the user, the questionID of the question related to the user, 
-- and the answer the user has given is stored together with a timestamp of when the question was answered.    
INSERT INTO userquestions (
	userID, questionID, points, answerTimestamp)
VALUES
	(1, 1, 5, "2021-03-15 10:15:35"),
    (1, 2, 0, "2021-03-15 10:16:10"),
    (1, 3, 0, "2021-03-15 10:16:45"),
    (1, 4, 5, "2021-03-15 10:16:55"),
    (1, 5, 5, "2021-03-15 10:17:55"),
    (1, 6, 5, "2021-03-15 10:18:35"),
    (1, 7, 5, "2021-03-15 10:20:26"),
    (1, 8, 5, "2021-03-15 10:21:35"),
    (1, 9, 0, "2021-03-15 10:23:03"),
    (1, 10, 0, "2021-03-15 10:24:10"),
    (1, 11, 0, "2021-03-15 10:24:35"),
    (1, 12, 5, "2021-03-15 10:24:46"),
	
	(2, 1, 0, "2021-03-16 10:15:35"),
    (2, 2, 5, "2021-03-16 10:16:10"),
    (2, 3, 5, "2021-03-16 10:16:45"),
    (2, 4, 5, "2021-03-16 10:16:55"),
    (2, 5, 0, "2021-03-16 10:17:55"),
    (2, 6, 5, "2021-03-16 10:18:35"),
    (2, 7, 0, "2021-03-16 10:20:26"),
    (2, 8, 5, "2021-03-16 10:21:35"),
    (2, 9, 5, "2021-03-16 10:23:03"),
    (2, 10, 0, "2021-03-16 10:24:10"),
    (2, 11, 0, "2021-03-16 10:24:35"),
    (2, 12, 5, "2021-03-16 10:24:46"),
    
    (3, 1, 5, "2021-03-25 10:15:35"),
    (3, 2, 5, "2021-03-25 10:16:10"),
    (3, 3, 5, "2021-03-25 10:16:45"),
    (3, 4, 5, "2021-03-25 10:16:55"),
    (3, 5, 0, "2021-03-25 10:17:55"),
    (3, 6, 0, "2021-03-25 10:18:35"),
    (3, 7, 0, "2021-03-25 10:20:26"),
    (3, 8, 5, "2021-03-25 10:21:35"),
    (3, 9, 5, "2021-03-25 10:23:03"),
    (3, 10, 0, "2021-03-25 10:24:10"),
    (3, 11, 0, "2021-03-25 10:24:35"),
    (3, 12, 5, "2021-03-25 10:24:46"),
    
    (4, 1, 0, "2021-04-15 10:15:35"),
    (4, 2, 0, "2021-04-15 10:16:10"),
    (4, 3, 0, "2021-04-15 10:16:45"),
    (4, 4, 0, "2021-04-15 10:16:55"),
    (4, 5, 5, "2021-04-15 10:17:55"),
    (4, 6, 5, "2021-04-15 10:18:35"),
    (4, 7, 5, "2021-04-15 10:20:26"),
    (4, 8, 5, "2021-04-15 10:21:35"),
    (4, 9, 0, "2021-04-15 10:23:03"),
    (4, 10, 0, "2021-04-15 10:24:10"),
    (4, 11, 0, "2021-04-15 10:24:35"),
    (4, 12, 5, "2021-04-15 10:24:46"),
    
    (5, 1, 5, "2021-04-17 10:15:35"),
    (5, 2, 5, "2021-04-17 10:16:10"),
    (5, 3, 0, "2021-04-17 10:16:45"),
    (5, 4, 5, "2021-04-17 10:16:55"),
    (5, 5, 5, "2021-04-17 10:17:55"),
    (5, 6, 0, "2021-04-17 10:18:35"),
    (5, 7, 5, "2021-04-17 10:20:26"),
    (5, 8, 5, "2021-04-17 10:21:35"),
    (5, 9, 0, "2021-04-17 10:23:03"),
    (5, 10, 5, "2021-04-17 10:24:10"),
    (5, 11, 5, "2021-04-17 10:24:35"),
    (5, 12, 5, "2021-04-17 10:24:46"),
    
    (6, 1, 0, "2021-04-20 10:15:35"),
    (6, 2, 5, "2021-04-20 10:16:10"),
    (6, 3, 5, "2021-04-20 10:16:45"),
    (6, 4, 0, "2021-04-20 10:16:55"),
    (6, 5, 0, "2021-04-20 10:17:55"),
    (6, 6, 0, "2021-04-20 10:18:35"),
    (6, 7, 5, "2021-04-20 10:20:26"),
    (6, 8, 5, "2021-04-20 10:21:35"),
    (6, 9, 5, "2021-04-20 10:23:03"),
    (6, 10, 5, "2021-04-20 10:24:10"),
    (6, 11, 0, "2021-04-20 10:24:35"),
    (6, 12, 5, "2021-04-20 10:24:46"),
    
    (7, 1, 5, "2021-05-15 10:15:35"),
    (7, 2, 5, "2021-05-15 10:16:10"),
    (7, 3, 5, "2021-05-15 10:16:45"),
    (7, 4, 5, "2021-05-15 10:16:55"),
    (7, 5, 5, "2021-05-15 10:17:55"),
    (7, 6, 5, "2021-05-15 10:18:35"),
    (7, 7, 5, "2021-05-15 10:20:26"),
    (7, 8, 0, "2021-05-15 10:21:35"),
    (7, 9, 0, "2021-05-15 10:23:03"),
    (7, 10, 5, "2021-05-15 10:24:10"),
    (7, 11, 0, "2021-05-15 10:24:35"),
    (7, 12, 5, "2021-05-15 10:24:46"),
    
	(8, 1, 0, "2021-06-15 10:15:35"),
    (8, 2, 0, "2021-06-15 10:16:10"),
    (8, 3, 0, "2021-06-15 10:16:45"),
    (8, 4, 0, "2021-06-15 10:16:55"),
    (8, 5, 5, "2021-06-15 10:17:55"),
    (8, 6, 5, "2021-06-15 10:18:35"),
    (8, 7, 5, "2021-06-15 10:20:26"),
    (8, 8, 5, "2021-06-15 10:21:35"),
    (8, 9, 5, "2021-06-15 10:23:03"),
    (8, 10, 5, "2021-06-15 10:24:10"),
    (8, 11, 0, "2021-06-15 10:24:35"),
    (8, 12, 5, "2021-06-15 10:24:46"),
    
	(9, 1, 0, "2021-05-17 10:15:35"),
    (9, 2, 0, "2021-05-17 10:16:10"),
    (9, 3, 0, "2021-05-17 10:16:45"),
    (9, 4, 5, "2021-05-17 10:16:55"),
    (9, 5, 0, "2021-05-17 10:17:55"),
    (9, 6, 5, "2021-05-17 10:18:35"),
    (9, 7, 5, "2021-05-17 10:20:26"),
    (9, 8, 0, "2021-05-17 10:21:35"),
    (9, 9, 5, "2021-05-17 10:23:03"),
    (9, 10, 5, "2021-05-17 10:24:10"),
    (9, 11, 0, "2021-05-17 10:24:35"),
    (9, 12, 5, "2021-05-17 10:24:46");

-- Initial Select statement to show the relevant points under each category for each user.  
SELECT * FROM usersPointsPerCategory;


-- ********************************************
-- EXTRA
-- *******************************************

-- Inserting into the userTotalResult table.
-- The precondition for this table to be filled with data, is that the points that each user gets for each question
-- is summed in the logic layer, followed by storing that total number per category in this table.
-- We have alligned the data with the data in the other tables above to make it relevant.
INSERT INTO userTotalResult (userID, Creative, Development, DigitalMarketing)
VALUES 
	(1, 10, 20, 5),
    (2, 15, 10, 10),
    (3, 20, 5, 10),
    (4, 0, 20, 5),
    (5, 15, 15, 15),
    (6, 10, 10, 15),
    (7, 20, 15, 10),
    (8, 0, 20, 15),
    (9, 5, 10, 15);
   


    