-- Database for handling and storing information regarding CodersTrusts users, who fill out the "career-quiz".
-- Developed by Jacob Berg, Jørn Møller, Alexander Broersen, Eliza Hansen and Christian F.-Nielsen. 
-- Group 19, 2. semester BE-IT KEA 2021

-- ********************************************
-- CREATE THE CTDB DATABASE
-- *******************************************

-- Creating the Database
DROP DATABASE IF EXISTS ctdb;
CREATE DATABASE CTDB;

-- Using the Database
use CTDB;

-- Creating the table for users. 
-- Note that userName and userEmail have allowed values NULL UNIQUE. 
-- This makes it possible to store unique users who have logged in, 
-- aswell as multiple anonymous users, for future statistics.
create table if not exists users (
	userID int NOT NULL auto_increment,
    userName varchar (255) NULL UNIQUE,
    userPassword varchar (255),
    userEmail varchar (255) NULL UNIQUE,
    PRIMARY KEY (userID));
    
-- Creating the table for categories
create table if not exists categories (
	categoryID int NOT NULL auto_increment,
    categoryName varchar (255) UNIQUE,
    PRIMARY KEY (categoryID));
    
-- Creating the table for questions.
-- As multiple questions can fall under the same category,
-- a foreign key (categoryID) has been added, pointing towards the primary key of the categories-table. 
create table if not exists questions (
	questionID int NOT NULL auto_increment,
    categoryID int NOT NULL,
    questionDescription varchar (255) UNIQUE,
    PRIMARY KEY (questionID),
    CONSTRAINT	fk_categories
		FOREIGN KEY (categoryID)
        REFERENCES categories (categoryID));
    
    
-- creating the table userQuestions.
-- Userquestions is a junction table between users and questions.
-- As there is a many-to-many relation between users and questions, we have eliminated that relation
-- by creating the junction table. THe primary key is a combined primary key that consists of the
-- combination of the primary keys from users and questions. By doing so we make sure that one user
-- only can be stored once for every unique question. Same goes for the other way around, where
-- a question only can be stored for every unique user.
-- furthermore a "points" attribute has been added, where the only values allowed are 0 and 5.
-- This constraint helps support the request of giving a user 5 points for each question answered with "yes".
-- If the user answers "no", the value of "points" related to that particular user and question combination,
-- will be 0.
-- The last attribute added to this table is the "answerTimestamp" attribute. We have added this for the purpose
-- of future statistic analysis. Employees of CodersTrust will then be able to search for what has been answered
-- in a given timeperiod (for example; january through march 2021 or the whole year of 2022), or how long it took
-- users to answer a single question. With this, employees of CodersTrust can analyse wether the question is too
-- complicated or if its even relevant.
create table if not exists userQuestions (
	userID int,
    questionID int,
    points int, check (points = 0 OR points = 5),
    answerTimestamp timestamp,
    CONSTRAINT user_question_pk PRIMARY KEY (userID, questionID),
    CONSTRAINT fk_users
		FOREIGN KEY (userID) REFERENCES users (userID),
	CONSTRAINT fk_questions
		FOREIGN KEY (questionID) REFERENCES questions (questionID));
   
   
-- Creating the usersPointsPerCategory View.
-- This view is created to avoid complexity when searching for users and their total points for each category
-- It takes the sum of all points that a user has for each given category.
CREATE VIEW usersPointsPerCategory AS   
	SELECT 
		users.userID, userName, SUM(points) AS pointsPerCategory, categoryName
	FROM
		userquestions
	INNER JOIN
		questions ON questions.questionID = userquestions.questionID
	INNER JOIN
		categories ON categories.categoryID = questions.categoryID
	INNER JOIN
		users ON users.userID = userquestions.userID
	GROUP BY categoryName, users.userID
	ORDER BY userID;
-- We also wanted to create a view that calculated these given points per category into percentage of total points
-- but we couldnt manage to create the qeuery supporting this. Our closest try is as follows:
-- ////SELECT 
-- 			userID, userName, percentagePerCategory, categoryName
-- 	FROM 
-- 		(SELECT userID, userName, pointsPerCategory / SUM(pointsPerCategory) * 100 AS percentagePerCategory, categoryName
-- 		FROM 
-- 			usersPointsPerCategory 
-- 			GROUP BY userID, categoryName) AS subqeury;////
-- Replacing the SUM(pointsPerCategory) with a given number, say 40, will actually calculate how big of a percentage
-- each given pointsPerCategory is of 40; pointsPerCategory / 40 * 100. 
-- But when using SUM(pointsPerCategory) it apparently just calculates it as (pointsPerCategory / pointsPercategory * 100).
-- this view does support sending and displaying the results to each user, given the percentage calculation and pie-chart
-- formatting happens in the logical layer(Python for example).
    
    
-- Creating the usersHighestValuedCategory
-- This view is created to avoid complexity when searching for the category that each user has scored
-- the highest points in. it is also sorted by categoryName and userID
CREATE VIEW usersHighestValuedCategory AS
	SELECT 
		uppc.*
	FROM 
		usersPointsPerCategory uppc
	INNER JOIN
		(SELECT 
			userName, MAX(pointsPerCategory) AS highestPoints
		FROM 
			usersPointsPerCategory
		GROUP BY userName) groupeduppc
	ON uppc.userName = groupeduppc.userName
	AND uppc.pointsPerCategory = groupeduppc.highestPoints
    ORDER BY categoryName, userID;
-- This view is relevant, as it shows the category that each users has scored the highest points in.
-- What we have failed to include is the other categories´ values for each user. If a qeury that can
-- include this is possible to create, it would make the data more relevant when doing statistics.
-- As we failed to do so, we have suggested that the calculation of comparison when searching for users
-- with the highest score in for example "Development", happens in the logical layer. 



-- ********************************************
-- EXTRA
-- *******************************************

-- As we see the above tables as the most logic way to store and relate the incoming data, we want to keep this as
-- our primary solution. Unfortunately, the queries to display the data the way CodersTrust requests
-- seem to be very complex to execute with our given database. 
-- 
-- Below we have created an extra table holding the userID pointing to the userID in the users table.
-- It also holds the variables Creative, Development and DigitalMarketing, which holds the users total points
-- in each category. Setting it up like this makes the qeury to display the percentage of each category
-- aswell as the qeury to show all the users with highest scored points in a specific category a lot less complex.
-- in order for this table to be filled with relevant data, the calculation of summing each users points happens
-- in the logic layer (fx Python). The DML qeury for this is shown in the "Extra" section in the "CTDB DML SCRIPT".

-- Creating a table holding a users total result for each category
create table userTotalResult (
	userID int NOT NULL,
    Creative int,
    Development int,
    DigitalMarketing int,
    PRIMARY KEY (userID),
    CONSTRAINT fk_userID
		FOREIGN KEY (userID) REFERENCES users (userID));


-- Creating the view userResultInPercentage
-- This view takes the data from userTotalResult and calculates the point distribution in percentage 
CREATE VIEW userResultInPercentage AS
	SELECT 
		users.userName, 
		Creative / (Creative+Development+DigitalMarketing) * 100 AS CreativePercentage, 
		Development / (Creative+Development+DigitalMarketing) * 100 AS DevelopmentPercentage,
		DigitalMarketing / (Creative+Development+DigitalMarketing) * 100 AS DigitalMarketingPercentage
	FROM userTotalResult
	INNER JOIN users ON users.userID = userTotalResult.userID;
 
-- Creating the view usersWithDigitalMarketingPreference
-- This view shows all users who have scored the highest in Digital Marketing
CREATE VIEW usersWithDigitalMarketingPreference AS   
	SELECT
		userName, DigitalMarketingPercentage, CreativePercentage, DevelopmentPercentage
	FROM userResultInPercentage
	WHERE DigitalMarketingPercentage > DevelopmentPercentage AND DigitalMarketingPercentage > CreativePercentage;


-- Creating the view usersWithDevelopmentPreference
-- This view shows all users who have scored the highest in Development
CREATE VIEW usersWithDevelopmentPreference AS
	SELECT
		userName, DevelopmentPercentage, CreativePercentage, DigitalMarketingPercentage
	FROM userResultInPercentage
	WHERE DevelopmentPercentage > CreativePercentage AND DevelopmentPercentage > DigitalMarketingPercentage;


-- Creating the view usersWithCreativePreference
-- This view shows all users who have scored the highest in Creative
CREATE VIEW usersWithCreativePreference AS
	SELECT
		userName, CreativePercentage, DigitalMarketingPercentage, DevelopmentPercentage
	FROM userResultInPercentage
	WHERE CreativePercentage > DevelopmentPercentage AND CreativePercentage > DigitalMarketingPercentage;
    
	
